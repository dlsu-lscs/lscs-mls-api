// Authentication middleware
