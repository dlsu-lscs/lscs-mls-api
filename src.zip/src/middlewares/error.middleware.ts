// Centralized error handler
